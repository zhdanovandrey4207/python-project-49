### Hexlet tests and linter status:
[![Actions Status](https://github.com/zhdanovandrey4207/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/zhdanovandrey4207/python-project-49/actions)
<a href="https://codeclimate.com/github/zhdanovandrey4207/python-project-49/test_coverage"><img src="https://api.codeclimate.com/v1/badges/a3a15b5a51236860b6e3/test_coverage" /></a>
